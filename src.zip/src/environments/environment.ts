export const environment = {
  production: false,
  firebase: {
    apiKey: "AIzaSyDRgr7Xwtpba9hD9JIA8pdg28WuknIJIls",
    authDomain: "dotpeadmin.firebaseapp.com",
    databaseURL: "https://dotpeadmin.firebaseio.com",
    projectId: "dotpeadmin",
    storageBucket: "dotpeadmin.appspot.com",
    messagingSenderId: "322886006543",
    appId: "1:322886006543:web:c5be468572a5f59fd9b07a"
  }
}
