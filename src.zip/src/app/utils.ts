export const usersCollection = 'users';
export const employeeCollection = 'employees';
