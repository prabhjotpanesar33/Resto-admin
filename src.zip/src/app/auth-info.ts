export interface Roles {
    subscriber?: boolean;
    editor?: boolean;
    admin?: boolean;
 }

export interface AuthInfo {
    claims:any
}
