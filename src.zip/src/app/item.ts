import { DotpeService } from "src/app/dotpe.service";
export class  item{
  id : string;
  itemId : string;
//  category : string;
  name : string;
  type : string;
  price : string;
  imagePath : string;

}
export class category{
  id : string
  itemId : string
  name : string;
}

