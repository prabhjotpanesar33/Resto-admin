export class EmployeeModel{
    name: string;
//    empId: string;
    email: string;
    password: string;
    isActive: boolean;
   roles: {};
//    createDate: Date;
}

// status
// 0 not finished
// 1 finished
