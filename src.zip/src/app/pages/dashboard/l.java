class simple{
  public static void main(string args[]){
    system.out.println("HELLO JAVA");
  }
  }
